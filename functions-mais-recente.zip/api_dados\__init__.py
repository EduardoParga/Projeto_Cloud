import pymssql
import json
import logging
import os
from datetime import datetime
import azure.functions as func

def main(req: func.HttpRequest) -> func.HttpResponse:
    """
    API para retornar dados de cotações B3 SEMPRE DO ARQUIVO MAIS RECENTE DISPONÍVEL
    """
    logging.info('🔍 API dados iniciada - Buscando arquivo B3 MAIS RECENTE')
    
    try:
        # Parâmetros da requisição
        ativo_solicitado = req.params.get('ativo')
        
        # Configuração do banco Azure SQL  
        server = 'sqlb3server123.database.windows.net'
        database = 'b3database'
        username = 'b3admin'  # Usuário correto
        password = 'SenhaSegura123!'  # Senha correta
        
        logging.info(f'📊 Conectando ao Azure SQL: {server}/{database}')
        
        # Conectar ao banco
        conn = pymssql.connect(
            server=server,
            user=username,
            password=password,
            database=database,
            timeout=30
        )
        cursor = conn.cursor()
        
        # 1. PRIMEIRO: Identificar o arquivo B3 MAIS RECENTE
        query_arquivo_recente = """
        SELECT 
            MAX(DataProcessamento) as ArquivoMaisRecente,
            COUNT(*) as TotalRegistros,
            MIN(Data) as DataInicialPregao,
            MAX(Data) as DataFinalPregao
        FROM Cotacoes
        """
        
        cursor.execute(query_arquivo_recente)
        info_arquivo = cursor.fetchone()
        
        if not info_arquivo or not info_arquivo[0]:
            raise Exception('Nenhum arquivo B3 encontrado no banco de dados')
        
        arquivo_mais_recente = info_arquivo[0]
        total_registros_arquivo = info_arquivo[1]
        data_inicial_pregao = info_arquivo[2]
        data_final_pregao = info_arquivo[3]
        
        logging.info(f'📅 Arquivo MAIS RECENTE encontrado: {arquivo_mais_recente}')
        logging.info(f'📊 Total de registros no arquivo: {total_registros_arquivo}')
        
        # 2. SEGUNDO: Buscar dados APENAS DO ARQUIVO MAIS RECENTE
        query_dados = """
        SELECT 
            Ativo as simbolo,
            Data as data,
            Abertura as abertura,
            Minimo as minimo,
            Maximo as maximo,
            Fechamento as fechamento,
            Volume as volume,
            Negocios as negocios,
            DataProcessamento
        FROM Cotacoes 
        WHERE DataProcessamento = ?
        """
        
        # Se um ativo específico foi solicitado, filtrar por ele
        if ativo_solicitado:
            query_dados += " AND Ativo = ? ORDER BY Ativo"
            cursor.execute(query_dados, (arquivo_mais_recente, ativo_solicitado.upper()))
            logging.info(f'🎯 Buscando {ativo_solicitado} do arquivo MAIS RECENTE ({arquivo_mais_recente})')
        else:
            query_dados += " ORDER BY Ativo"
            cursor.execute(query_dados, (arquivo_mais_recente,))
            logging.info(f'📊 Buscando TODOS os ativos do arquivo MAIS RECENTE ({arquivo_mais_recente})')
        
        rows = cursor.fetchall()
        
        if not rows:
            if ativo_solicitado:
                raise Exception(f'Ativo {ativo_solicitado} não encontrado no arquivo B3 mais recente')
            else:
                raise Exception('Nenhum dado encontrado no arquivo B3 mais recente')
        
        # 3. TERCEIRO: Converter dados para formato JSON
        cotacoes = []
        for row in rows:
            cotacoes.append({
                'simbolo': row[0],
                'data': row[1].strftime('%Y-%m-%d') if row[1] else None,
                'abertura': float(row[2]) if row[2] else 0,
                'minimo': float(row[3]) if row[3] else 0,
                'maximo': float(row[4]) if row[4] else 0,
                'fechamento': float(row[5]) if row[5] else 0,
                'volume': int(row[6]) if row[6] else 0,
                'negocios': int(row[7]) if row[7] else 0,
                'data_processamento': row[8].strftime('%Y-%m-%d %H:%M:%S') if row[8] else None
            })
        
        cursor.close()
        conn.close()
        
        # 4. QUARTO: Preparar resposta com informações do arquivo mais recente
        response_data = {
            'dados': cotacoes,
            'total': len(cotacoes),
            'status': 'success',
            'arquivo_info': {
                'data_processamento': arquivo_mais_recente.strftime('%Y-%m-%d %H:%M:%S'),
                'data_processamento_formatada': arquivo_mais_recente.strftime('%d/%m/%Y %H:%M'),
                'total_registros_arquivo': total_registros_arquivo,
                'data_pregao_inicial': data_inicial_pregao.strftime('%Y-%m-%d') if data_inicial_pregao else None,
                'data_pregao_final': data_final_pregao.strftime('%Y-%m-%d') if data_final_pregao else None,
                'eh_arquivo_mais_recente': True
            },
            'fonte': f'Azure SQL Database - Arquivo B3 MAIS RECENTE ({arquivo_mais_recente.strftime("%d/%m/%Y %H:%M")})'
        }
        
        if ativo_solicitado:
            logging.info(f'✅ Retornando {len(cotacoes)} registros para {ativo_solicitado} do arquivo MAIS RECENTE')
        else:
            logging.info(f'✅ Retornando {len(cotacoes)} registros de TODOS os ativos do arquivo MAIS RECENTE')
        
        return func.HttpResponse(
            json.dumps(response_data, ensure_ascii=False),
            status_code=200,
            headers={
                'Content-Type': 'application/json; charset=utf-8',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization'
            }
        )
        
    except Exception as e:
        logging.error(f'❌ Erro na API dados: {str(e)}')
        
        error_response = {
            'error': str(e),
            'status': 'error',
            'total': 0,
            'arquivo_info': {
                'erro': 'Não foi possível identificar o arquivo mais recente'
            },
            'fonte': 'Azure SQL Database - ERRO ao buscar arquivo mais recente'
        }
        
        return func.HttpResponse(
            json.dumps(error_response, ensure_ascii=False),
            status_code=500,
            headers={
                'Content-Type': 'application/json; charset=utf-8',
                'Access-Control-Allow-Origin': '*'
            }
        )