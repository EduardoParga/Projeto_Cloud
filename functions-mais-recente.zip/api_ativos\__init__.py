import json
import logging
import azure.functions as func
import pymssql

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('🔄 API Ativos - Buscando ativos REAIS do Azure SQL Database')
    
    try:
        # Conectar ao Azure SQL Database para buscar ativos DINÂMICOS
        conn = pymssql.connect(
            server='sqlb3server123.database.windows.net',
            user='b3admin',
            password='SenhaSegura123!',
            database='b3database'
        )
        
        ativos_reais = []
        
        with conn.cursor() as cursor:
            # Buscar TODOS os ativos únicos do banco (dinâmico)
            cursor.execute("""
                SELECT DISTINCT Ativo
                FROM Cotacoes 
                ORDER BY Ativo
            """)
            
            resultados = cursor.fetchall()
            ativos_reais = [row[0] for row in resultados]
        
        conn.close()
        
        response = {
            'ativos': ativos_reais,
            'total': len(ativos_reais),
            'status': 'success',
            'fonte': 'Azure SQL Database - Ativos DINÂMICOS da B3 (atualizados diariamente)'
        }
        
        logging.info(f'✅ Retornando {len(ativos_reais)} ativos REAIS: {ativos_reais}')
        
        return func.HttpResponse(
            json.dumps(response, ensure_ascii=False),
            mimetype="application/json",
            headers={'Access-Control-Allow-Origin': '*'}
        )
        
    except Exception as e:
        logging.error(f'❌ Erro na API Ativos: {str(e)}')
        
        # Fallback com ativos fixos em caso de erro
        ativos_fallback = ['ITUB4', 'PETR4', 'VALE3']
        
        return func.HttpResponse(
            json.dumps({
                'ativos': ativos_fallback,
                'total': len(ativos_fallback),
                'status': 'fallback',
                'erro': str(e),
                'fonte': 'Dados de fallback - erro na conexão com Azure SQL'
            }, ensure_ascii=False),
            mimetype="application/json",
            headers={'Access-Control-Allow-Origin': '*'}
        )
        return func.HttpResponse(
            json.dumps({'error': str(e), 'status': 'error'}),
            status_code=500,
            mimetype="application/json",
            headers={'Access-Control-Allow-Origin': '*'}
        )